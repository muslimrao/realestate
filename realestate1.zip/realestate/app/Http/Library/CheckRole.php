<?php
namespace App\Http\Library;


use Mage;
use Auth;

class CheckRole  {


    
    public function is( $role_name = false  )
    {
        
        die( $role_name );
        
    }
    
    public function isAdmin()
    {
        die("z");
    }
    
 
	
}