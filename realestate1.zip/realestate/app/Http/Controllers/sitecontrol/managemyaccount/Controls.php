<?php

namespace App\Http\Controllers\sitecontrol\Managemyaccount;

use App\Http\Library\RoleManagement;
use App\Http\Controllers\My_controller;
use App\Http\Helpers\GeneralHelper;
use App\Http\Library\CustomHasher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use \Illuminate\Support\Facades\Session;
use Validator;
use Illuminate\Support\Facades\Config;
use \App\Http\Helpers\DropdownHelper;
use DB;

class Controls extends MY_controller
{

    public function __construct()
    {
        parent::__construct();
		
		
        $this->data                                             = $this->default_data();


        $this->data["_heading"]									= 'Manage My Account';
        $this->data["_pagetitle"]								= $this->data["_heading"] . " - ";
        $this->data["_directory"]                               = "sitecontrol/managemyaccount/";
		
        
    }

    public function view( $is_ajax = 0 )
    {
        return redirect( $this->data["_directory"] . "controls/edit/" . RoleManagement::getCurrent_LoggedInID(  Config::get('constants.GUARD_SUPERADMIN')  ) );
    }

    public function edit( $edit_id = false )
    {        
	
	
        if ( !$this->_auth_current_logged_in_ID($edit_id, Config::get('constants.GUARD_SUPERADMIN')) )
        {
			
            return redirect	( 	
								$this->data["_directory"] . "controls/edit/" . 
								RoleManagement::getCurrent_LoggedInID( Config::get('constants.GUARD_SUPERADMIN') ) 
							);
        }
		
		
		
		$this->data['_pageview']									= $this->data["_directory"] . "edit";
     
	
        $this->data["edit_id"]                                      = $edit_id; 



        $edit_details												= Auth::guard( Config::get('constants.GUARD_SUPERADMIN') ) -> user()->toArray();
		$edit_details['current_password']							= "";
		$edit_details['new_password']								= "";
		$edit_details['new_confirm_password']						= "";
		$edit_details['user_image']									= "";
		
        $edit_details['options']									= "edit";
        $edit_details['unique_formid']								= "";
		



        
       
        $this->_create_fields_for_form(true, $this->data, $edit_details );

	

        return view( Config::get('constants.ADMINCMS_TEMPLATE_VIEW'), $this->data );

    
		
    }
	
	
	public function _create_fields_for_form( $return_array = false, &$data, $db_data = array() )
	{
		
		$empty_inputs               = array( "id", "username", "current_password", "new_password", "new_confirm_password", "email", "user_image", "status", "options", "unique_formid" );
		
		$filled_inputs              = array( "id", "username", "current_password", "new_password", "new_confirm_password", "email", "user_image", "status", "options", "unique_formid" );
		
		
		
		if ($return_array == true)
		{
			for ($x=0;  $x < count($empty_inputs); $x++)
			{
				$explode_empty_inputs			= explode( "|", $empty_inputs[$x] );
				$empty_inputs[$x]				= $explode_empty_inputs[0];
				$tmp_value						= $db_data[ $filled_inputs[$x] ];
				
				if ( count($explode_empty_inputs) > 1 )
				{
					switch ( $explode_empty_inputs[1] )
					{
						case "default_date":	
							$tmp_value			= date("d-m-Y", strtotime( $db_data[ $filled_inputs[$x] ] ) );
							break;
							
						case "default":	
							break;
					}
				}
				
				$data[ $empty_inputs[$x] ]		= $tmp_value;
				
			}
			
		}
		else
		{
		
			for ($x=0;  $x < count($empty_inputs); $x++)
			{
				
				$explode_empty_inputs				= explode( "|", $empty_inputs[$x] );
				$empty_inputs[$x]					= $explode_empty_inputs[0];
				$tmp_value							= "";
				
				
				if ( count($explode_empty_inputs) > 1 )
				{
					switch ( $explode_empty_inputs[1] )
					{
						case "default_date":	
							$tmp_value				= "00-00-0000";
							break;
							
						case "default":	
							break;
					}
				}
				
				$data[ $empty_inputs[$x] ]		= $tmp_value;
			}
		}
	}
	
}
