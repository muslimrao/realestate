<?php
return [
    'GUARD_SUPERADMIN'    				=> 'admin',
	
	
	'ADMINCMS_TEMPLATE_VIEW'    		=> 'sitecontrol/template/index',
];
